<?php 
require('db.php');
$row=mysqli_fetch_assoc(mysqli_query($con,"select status from users where id=' ".$_SESSION['UID']." ' "));
echo $row['status'];
?>
